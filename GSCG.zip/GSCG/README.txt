GSCG:  generalized shrinkage conjugate gradient 

               

Written by:
Hamid Esmaeili, Morteza Kimiaei and Shima Shabani  
-------------------------------------------------------------

1.  Introduction
================

 GSCG is generalized shrinkage conjugate gradient method to solve the L_1-regularized convex
 minimization problem for sparse recovery ( applied to compressed sensing and image deblurring problems)
           
                         min (1/2)*||Ax - b||_M^2+ mu*||x||_1 
 
2.  Getting Started
===================

The driver_cs.m file generate random compressed sensing problems automatically and solves them by the methods in the functions folder via calling some 
utilizers from the utilizers folder. Inorder to run it, you should just set functions and utilizers folders in MATLAB path. 
This m.file saves all of the desired outputs of the all solvers in mat.files automatically.


4.  Contact Information
=======================

GSCG is available at https://github.com/. Please
feel free to e-mail the authors with any comments or suggestions:

    Hamid Esmaeili     <esmaeili@basu.ac.ir>
    Morteza Kimiaei    <kimiaeim83@univie.ac.at>
    Shima Shabani      <sh.shabani@basu.ac.ir>
   
5.  Copyright Notice
====================

GSCG is free software; you can redistribute it and/or modify it under the 
terms of the GNU General Public License as published by the Free Software 
Foundation.

This program is distributed in the hope that it will be useful, but WITHOUT 
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or 
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.