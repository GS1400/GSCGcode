
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% driver_cs %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear;
close all;

global n A b M options 


Ameth    = 0;  % indicates what type of A matrix is being passed.;
               % Ameth \in {0,1,...,6}
xmeth    = 0;  % determines xs structure; xmeth \in {0,1,2,3}
Slist    = {'fpcbb' 'fpc' 'GSCG'}; % contain the list of solvers
sig1     = 1E-7 ; % std. dev. of signal noise
sig2     = sig1;  % "   "   " measurement noise
rho      = 0.1;
delta    = 0.1;

%%%%%%%%%%%%%%%%
% problem size %
%%%%%%%%%%%%%%%%
n        = 2^12;
m        = round(delta*n);
k0       = round(rho*m);


%%%%%%%%%%%%%%%%%%  
% select options %
%%%%%%%%%%%%%%%%%%

mu             = 2^(-8); 
options.mu     = mu;
options.init   = 2; 
options.xtol   = 1E-10;
options.ftol   = 1E-10;
options.gtol   = 0.2;
options.mxitr  = 10000;
options.eta    = 4;
options.fullMu = false;
options.gamma  = 0.85; 
options.c      = 1E-3; 
options.beta   = 0.5;
options.scale  = true;
options.stopCriterion = 1;

%%%%%%%%%%%%%%%%%%%%
% generate problem %
%%%%%%%%%%%%%%%%%%%%

alpha    = 0.5; 
seed     = 0;
full     = true;
  
% obtain A,b,xs,xsn
[A,b,xs,xsn] = getData(m,n,k0,Ameth,xmeth,sig1,sig2,seed);
[M,mu_rec,A,b,sig,kap,tau,M12] = ...
             getM_mu(full,m,n,Ameth,A,b,sig1,sig2,alpha);

 if ~isempty(M), A=M12*A; b=M12*b; M=[]; end

  options.kappa = kap;
  options.xs    = xs;
                                        
   for j = 1:length(Slist) 

       fprintf(['Running ',Slist{j},'...\n'])
                
        tic
        eval(['Output=',Slist{j},';'])      
        toc
               
        eval(['itern.',Slist{j},'=Output.iterfinal;'])
        eval(['Time.',Slist{j},'=Output.cpu;'])
        eval(['funccount.',Slist{j},'=Output.nf;'])
        eval(['mse.',Slist{j},'=Output.mse;'])
        eval(['Nonzeros.',Slist{j},'=Output.nz;'])
        eval(['x.',Slist{j},'=Output.x;'])
                
                
        F = Output.f;
        F_best = F(1);
        for k = 2 : length(F)
            if F(k) < F_best
               F_best = F(k);
            end
            F(k)   = F_best;
        end
        F = F';             
        eval(['f_',Slist{j},'=F;'])
            
                
        FF = Output.n2re;
        FF_best = FF(1);
        for k = 2 : length(FF)
            if FF(k) < FF_best
               FF_best = FF(k);
             end
             FF(k)   = FF_best;
        end
        
        FF = FF';
        eval(['n2re_',Slist{j},'=FF;'])
              
  end   
   
figure(1)

legendname = {''};

color      = {'b' 'r' 'g' 'k'};
lines      = {':' '.-' '--' '-'};
linewid    = [3 0.1 1.75 1.75];

for k = 1: length(Slist)
   
    xk = floor(exp((1:20)*(log(length(['f_',Slist{k}]))/20)));
    eval(['Fk = f_',Slist{k},'(xk);'])
    loglog(xk,Fk,[lines{k},color{k}],'LineWidth',linewid(k))
       
    legendname{k}=Slist{k};
    hold on
    xlabel('iterations');
    ylabel('function values');
    legend(legendname,1);
    
end

for k = 1: length(Slist)
   eval(['Fk = f_',Slist{k},';'])
   loglog(Fk,[lines{k},color{k}],'LineWidth',linewid(k))
   hold on
end

com = ['print -depsc -noui  Figure',num2str(Ameth),'.1'];
eval(com)


figure(2)

legendname = {''};

for k = 1: length(Slist)
    
    xxk = floor(exp((1:20)*(log(length(['n2re_',Slist{k}]))/20)));
    eval(['FFk = n2re_',Slist{k},'(xxk);'])
    loglog(xxk,FFk,[lines{k},color{k}],'LineWidth',linewid(k))
    legendname{k}=Slist{k};
    hold on
    xlabel('iterations');
    ylabel('||x - x_s||/||x_s||');
    legend(legendname,1);
end

for k = 1: length(Slist)
    eval(['nn2re=n2re_',Slist{k},';'])
    loglog(nn2re,[lines{k},color{k}],'LineWidth',linewid(k))
    hold on
end

com = ['print -depsc -noui  Figure',num2str(Ameth),'.2'];
eval(com)


figure(3)
plot(1:m,b,'b')
set(gca,'LineWidth',1.1)
set(gca,'FontName','Times New Roman')
set(gca,'FontSize',16)
title(sprintf(['Observation (m=',num2str(m),')']))
ylabel(sprintf('Amplitude'));
xlabel(sprintf('Index [1 m]'));

com = ['print -depsc -noui  Figure',num2str(Ameth),'.3'];
eval(com)


figure(4)
plot(1:n,xs,'b')
set(gca,'LineWidth',1.1)
set(gca,'FontName','Times New Roman')
set(gca,'FontSize',16)
title(sprintf(['Orginal Signal (n=',num2str(n),...
      ', k=',num2str(k0),')']))
ylabel(sprintf('Amplitude'));
xlabel(sprintf('Index [1 n]'));

com = ['print -depsc -noui  Figure',num2str(Ameth),'.4'];
eval(com)


for k = 1: length(Slist)
    figure(4+k)
    xsolver = eval(['x.',Slist{k}]);
    plot(1:n,xsolver,'ro',1:n,xs,'b')
    set(gca,'LineWidth',1.1)
    set(gca,'FontName','Times New Roman')
    set(gca,'FontSize',16)
    set(gca,'FontWeight','bold')
    title(sprintf([Slist{k},' (RelErr=', ...
          num2str(100*norm(xs-xsolver)/norm(xs)),')']))
    ylabel(sprintf('Amplitude'));
    xlabel(sprintf('Index [1 n]'));  
    com = ['print -depsc -noui  Figure',num2str(Ameth),'.',num2str(4+k)];
    eval(com)

end

                           
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                           
   
    